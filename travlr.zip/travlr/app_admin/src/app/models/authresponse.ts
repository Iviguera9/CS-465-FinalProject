export interface Authresponse {
    token: string;
}
